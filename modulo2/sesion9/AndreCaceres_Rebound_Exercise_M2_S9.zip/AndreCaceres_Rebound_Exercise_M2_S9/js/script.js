function ocultarMensaje(){
    document.getElementById('text2').style.display = "none";
}

function mostrarMensaje(){
    document.getElementById('text2').style.display = "block"
}

function agrandarMensaje(){
    document.getElementById('caja3').style.fontSize = "2em"
}

function achicarMensaje(){
    document.getElementById('caja3').style.fontSize = "1em"
}

function agrandarImagen(){
    document.getElementById('caja2').style.width = "200%"
}

function achicharImagen(){
    document.getElementById('caja2').style.width = "100%"
}